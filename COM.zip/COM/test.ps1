Write-Host "/******************   Hello World  *******************/"
mkdir d:\test\testdir

